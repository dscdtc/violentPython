Bluetooth Python extension module to allow Python "                "developers to use system Bluetooth resources. PyBluez works "                "with GNU/Linux and Windows XP.


