skyhooks
========

.. image:: https://cloud.github.com/downloads/serverdensity/skyhooks/skyhooks-in-tornados.png

``skyhooks`` comprises a collection of webhook handling utilities for
asynchronous Python apps, designed for use with Tornado, Gevent or Twisted.
